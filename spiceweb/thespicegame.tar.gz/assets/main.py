"""
main.py  -  Pygame Text Adventure Script Engine (PygBag / WebAssembly build)
Reads a .txt game script and renders it in a Pygame terminal window.

Local dev:   python main.py
Web build:   pygbag .   (run from the folder containing main.py)

WINDOW LAYOUT:
  +--------------------------------------+
  |  pixel art image (centered)          |
  ==========================================  <- blue line
  |  scrolling text output               |
  |  >  input prompt                     |
  ==========================================  <- blue line
  +--------------------------------------+
"""

import pygame, sys, os, time, random, textwrap, re, json, asyncio

# ─────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────
WIDTH          = 800
HEIGHT         = 600
FPS            = 60
scene_history  = []
BG_COLOR       = (8,   8,  16)
TEXT_COLOR     = (210, 200, 170)
INPUT_COLOR    = (255, 240, 180)
GOLD_COLOR     = (212, 175,  55)
ASIDE_COLOR    = (120, 140, 180)
WARN_COLOR     = (220, 100,  60)
BORDER_COLOR   = (60,  120, 220)
BORDER_WIDTH   = 2
FONT_FILE      = "HomeVideo.ttf"
FONT_SIZE      = 17
LINE_SPACING   = 6
MARGIN_X       = 32

IMAGE_AREA_H   = 180
BORDER_Y_TOP   = IMAGE_AREA_H + 8
BORDER_Y_BOT   = HEIGHT - 56
TEXT_AREA_TOP  = BORDER_Y_TOP + BORDER_WIDTH + 8
TEXT_AREA_BOT  = BORDER_Y_BOT - 8
MAX_LINES      = 80

TITLE_FONT_SIZE   = 28
CAPTION_FONT_SIZE = 18
HUD_TITLE_Y       = 8
HUD_CAPTION_Y     = IMAGE_AREA_H - 28

SCROLL_SPEED   = 3
CURSOR_BLINK   = 500

# ─────────────────────────────────────────────────────────────
# STATE
# ─────────────────────────────────────────────────────────────
vars_         = {}
scenes_       = {}
current_scene = "__main__"
flags_        = {}
line_buf      = []          # list of (text, color)
scroll_offset = 0

hud_title_text = "the silk road"
hud_desc_text  = "Travel from Constantinople to Calicut and trade spices."

# ─────────────────────────────────────────────────────────────
# PYGAME INIT
# ─────────────────────────────────────────────────────────────
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Road to Calicut")
clock  = pygame.time.Clock()

def load_font(size):
    try:
        return pygame.font.Font(FONT_FILE, size)
    except Exception:
        return pygame.font.SysFont("monospace", size)

font         = load_font(FONT_SIZE)
LINE_H       = font.get_height() + LINE_SPACING
title_font   = load_font(TITLE_FONT_SIZE)
caption_font = load_font(CAPTION_FONT_SIZE)

# ─────────────────────────────────────────────────────────────
# PIXEL IMAGE
# ─────────────────────────────────────────────────────────────
current_image = None

def _parse_col(v):
    if v is None: return None
    if isinstance(v, (list, tuple)): return tuple(v)
    named = {"black":(0,0,0),"white":(255,255,255),"red":(200,0,0),
             "green":(0,180,0),"blue":(0,0,200),"gold":(212,175,55),
             "yellow":(255,220,0),"brown":(139,90,43),"grey":(160,160,160)}
    return named.get(str(v).lower(), (255,255,255))

def build_pixel_surface(data):
    ps      = data.get("pixel_size", 6)
    palette = {k: _parse_col(v) for k, v in data.get("palette", {}).items()}
    rows    = data.get("data", [])
    if not rows: return None
    cols = max(len(r) for r in rows)
    surf = pygame.Surface((cols * ps, len(rows) * ps), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    for ri, row in enumerate(rows):
        for ci, cell in enumerate(row):
            color = palette.get(cell) if isinstance(cell, str) else _parse_col(cell)
            if color: pygame.draw.rect(surf, color, (ci*ps, ri*ps, ps, ps))
    return surf

def set_image(data):
    global current_image
    current_image = build_pixel_surface(data)

def load_image_file(path):
    global current_image
    try:
        if path.lower().endswith(".png"):
            current_image = pygame.image.load(path).convert_alpha()
        else:
            with open(path) as f:
                set_image(json.load(f))
    except Exception as e:
        push_line(f"[image error: {e}]", WARN_COLOR)

def clear_image():
    global current_image
    current_image = None

# ─────────────────────────────────────────────────────────────
# TEXT BUFFER
# ─────────────────────────────────────────────────────────────
def push_line(text, color=None):
    if color is None: color = TEXT_COLOR
    text = interpolate(str(text))
    max_chars = max(1, (WIDTH - MARGIN_X * 2) // max(1, font.size("A")[0]))
    for seg in text.splitlines():
        if seg.strip() == "":
            line_buf.append(("", color))
        else:
            for w in textwrap.wrap(seg, max_chars) or [""]:
                line_buf.append((w, color))
    while len(line_buf) > MAX_LINES:
        line_buf.pop(0)

def push_blank():
    line_buf.append(("", TEXT_COLOR))

# ─────────────────────────────────────────────────────────────
# DRAW
# ─────────────────────────────────────────────────────────────
def draw_frame(input_text="", cursor_vis=True, prompt_active=False):
    screen.fill(BG_COLOR)

    if current_image:
        iw, ih = current_image.get_size()
        screen.blit(current_image, ((WIDTH - iw) // 2, max(0, (IMAGE_AREA_H - ih) // 2)))

    if hud_title_text:
        t = title_font.render(hud_title_text, True, GOLD_COLOR)
        screen.blit(t, ((WIDTH - t.get_width()) // 2, HUD_TITLE_Y))

    if hud_desc_text:
        c = caption_font.render(hud_desc_text, True, TEXT_COLOR)
        screen.blit(c, ((WIDTH - c.get_width()) // 2, HUD_CAPTION_Y))

    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_TOP, WIDTH, BORDER_WIDTH))
    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_BOT, WIDTH, BORDER_WIDTH))

    text_h  = TEXT_AREA_BOT - TEXT_AREA_TOP
    max_vis = text_h // LINE_H
    display = list(line_buf)
    if prompt_active:
        cur = "_" if cursor_vis else " "
        display.append((">  " + input_text + cur, INPUT_COLOR))

    total   = len(display)
    bot_idx = total - scroll_offset
    top_idx = max(0, bot_idx - max_vis)
    bot_idx = min(bot_idx, total)

    for idx, (text, color) in enumerate(display[top_idx:bot_idx]):
        if text:
            screen.blit(font.render(text, True, color), (MARGIN_X, TEXT_AREA_TOP + idx * LINE_H))

    pygame.display.flip()

# ─────────────────────────────────────────────────────────────
# EVENT PUMP  (non-blocking, called every frame)
# ─────────────────────────────────────────────────────────────
# Input state shared between pump() and get_input()
_input_text    = ""
_input_ready   = False   # True when user pressed Enter
_input_result  = ""

def pump():
    global scroll_offset, _input_text, _input_ready, _input_result
    try:
        events = pygame.event.get()
    except Exception:
        return
    for event in events:
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()
            elif event.key == pygame.K_RETURN:
                _input_result = _input_text.strip()
                _input_text   = ""
                _input_ready  = True
            elif event.key == pygame.K_BACKSPACE:
                _input_text = _input_text[:-1]
            elif event.unicode and event.unicode.isprintable():
                _input_text += event.unicode
        if event.type == pygame.MOUSEWHEEL:
            scroll_offset = max(0, min(scroll_offset - event.y * SCROLL_SPEED,
                                       len(line_buf) - 1))

# ─────────────────────────────────────────────────────────────
# ASYNC INPUT
# ─────────────────────────────────────────────────────────────
async def get_input(prompt=""):
    """Async input: shows prompt, waits for Enter, returns string."""
    global scroll_offset, _input_ready, _input_result, _input_text
    if prompt:
        push_line(prompt, INPUT_COLOR)
    scroll_offset = 0
    _input_ready  = False
    _input_text   = ""
    cur_vis       = True
    last_blink    = pygame.time.get_ticks()

    while not _input_ready:
        now = pygame.time.get_ticks()
        if now - last_blink > CURSOR_BLINK:
            cur_vis    = not cur_vis
            last_blink = now
        pump()
        draw_frame(input_text=_input_text, cursor_vis=cur_vis, prompt_active=True)
        clock.tick(FPS)
        await asyncio.sleep(0)

    result       = _input_result
    _input_ready = False
    push_line(">  " + result, INPUT_COLOR)
    return result

async def wait_enter(msg="[ Press Enter to continue ]"):
    push_blank()
    push_line(msg, ASIDE_COLOR)
    await get_input()
    push_blank()

# ─────────────────────────────────────────────────────────────
# ASYNC FULLSCREEN IMAGE
# ─────────────────────────────────────────────────────────────
async def show_image_fullscreen(path, caption="", wait_secs=0.0):
    try:
        if path.lower().endswith(".png"):
            surf = pygame.image.load(path).convert_alpha()
        else:
            with open(path) as f:
                surf = build_pixel_surface(json.load(f))
    except Exception as e:
        push_line(f"[image error: {e}]", WARN_COLOR)
        return

    if surf is None:
        return

    font_cap = load_font(30)
    iw, ih   = surf.get_size()
    scale    = min(WIDTH / iw, HEIGHT / ih)
    if scale > 1:
        scale = max(1, int(scale))
    scaled   = pygame.transform.scale(surf, (int(iw * scale), int(ih * scale)))
    sw, sh   = scaled.get_size()
    ix       = (WIDTH  - sw) // 2
    iy       = (HEIGHT - sh) // 2
    cap_h    = 100 if caption else 0
    end_time = (asyncio.get_event_loop().time() + wait_secs) if wait_secs > 0 else None

    while True:
        pump()
        screen.fill((0, 0, 0))
        screen.blit(scaled, (ix, iy))
        if caption:
            cap_surf = pygame.Surface((WIDTH, cap_h))
            cap_surf.fill((0, 0, 0))
            cap_surf.set_alpha(210)
            screen.blit(cap_surf, (0, HEIGHT - cap_h))
            txt = font_cap.render(caption, True, (200, 190, 150))
            screen.blit(txt, (MARGIN_X, HEIGHT - cap_h + (cap_h - txt.get_height()) // 2))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
        if end_time and asyncio.get_event_loop().time() >= end_time:
            break

# ─────────────────────────────────────────────────────────────
# VARIABLE HELPERS
# ─────────────────────────────────────────────────────────────
def resolve(val):
    val = str(val).strip()
    if (val.startswith('"') and val.endswith('"')) or \
       (val.startswith("'") and val.endswith("'")):
        return val[1:-1]
    try: return int(val)
    except ValueError: pass
    try: return float(val)
    except ValueError: pass
    return vars_.get(val, val)

def interpolate(text):
    return re.sub(r'\{([^}]+)\}',
                  lambda m: str(vars_.get(m.group(1).strip(), "{"+m.group(1)+"}")), text)

def evaluate(cond):
    cond = cond.strip()
    m = re.match(r'^has\((.+)\)$', cond)
    if m: return m.group(1).strip().strip('"\'') in vars_.get("inventory", [])
    m = re.match(r'^flag\((.+)\)$', cond)
    if m: return bool(flags_.get(m.group(1).strip()))
    m = re.match(r'^not\s+flag\((.+)\)$', cond)
    if m: return not bool(flags_.get(m.group(1).strip()))
    for op in (">=","<=","!=","==",">","<"):
        if op in cond:
            l, r = cond.split(op, 1)
            lv, rv = resolve(l.strip()), resolve(r.strip())
            try: lv, rv = float(lv), float(rv)
            except (ValueError, TypeError): lv, rv = str(lv), str(rv)
            return {"==":lv==rv,"!=":lv!=rv,">=":lv>=rv,"<=":lv<=rv,">":lv>rv,"<":lv<rv}[op]
    v = vars_.get(cond)
    return bool(v) and str(v) not in ("false","False","0","")

# ─────────────────────────────────────────────────────────────
# PARSER
# ─────────────────────────────────────────────────────────────
def load_script(path):
    global scenes_
    scenes_, cur_name, cur_lines = {}, "__main__", []
    for raw in open(path, encoding="utf-8"):
        line = raw.rstrip("\n")
        s    = line.strip()
        if s.startswith("//"): continue
        if s.startswith("##"):
            scenes_[cur_name] = cur_lines
            cur_name, cur_lines = s[2:].strip(), []
        else:
            cur_lines.append(line)
    scenes_[cur_name] = cur_lines

# ─────────────────────────────────────────────────────────────
# ASYNC EXECUTOR
# ─────────────────────────────────────────────────────────────
async def run_lines(lines, start=0):
    global current_scene
    i = start
    while i < len(lines):
        line = lines[i].strip(); i += 1
        if not line or line.startswith("//"): continue

        # yield to browser every instruction
        pump()
        draw_frame()
        await asyncio.sleep(0)

        # ── print("...") ──────────────────────────────────────
        m = re.match(r'^print\("(.*)"\)$', line, re.DOTALL)
        if m: push_line(m.group(1)); continue

        # ── print_color("...", R, G, B) ───────────────────────
        m = re.match(r'^print_color\("(.*)",\s*(\d+),\s*(\d+),\s*(\d+)\)$', line)
        if m:
            push_line(m.group(1), (int(m.group(2)),int(m.group(3)),int(m.group(4))))
            continue

        # ── header("...") ─────────────────────────────────────
        m = re.match(r'^header\("(.*)"\)$', line)
        if m:
            push_blank(); push_line("==  "+m.group(1).upper()+"  ==", GOLD_COLOR); push_blank()
            continue

        # ── aside("...") ──────────────────────────────────────
        m = re.match(r'^aside\("(.*)"\)$', line)
        if m: push_line("  [ "+m.group(1)+" ]", ASIDE_COLOR); continue

        # ── warn("...") ───────────────────────────────────────
        m = re.match(r'^warn\("(.*)"\)$', line)
        if m: push_line("  !  "+m.group(1), WARN_COLOR); continue

        # ── typewrite("...") ──────────────────────────────────
        m = re.match(r'^typewrite\("(.*)"\)$', line)
        if m:
            text = interpolate(m.group(1)); push_line(""); displayed = ""
            for ch in text:
                displayed += ch
                line_buf[-1] = (displayed, TEXT_COLOR)
                pump(); draw_frame()
                await asyncio.sleep(0.03)
            continue

        # ── blank() ───────────────────────────────────────────
        if line == "blank()": push_blank(); continue

        # ── divider() ─────────────────────────────────────────
        if line == "divider()":
            push_line("  .  .  .  .  .  .  .  .  .  .  .  .  .", (60,80,120))
            continue

        # ── wait(n) ───────────────────────────────────────────
        m = re.match(r'^wait\(([\d.]+)\)$', line)
        if m:
            end = asyncio.get_event_loop().time() + float(m.group(1))
            while asyncio.get_event_loop().time() < end:
                pump(); draw_frame()
                await asyncio.sleep(0)
            continue

        # ── pause() ───────────────────────────────────────────
        if line == "pause()": await wait_enter(); continue

        # ── goBack() ──────────────────────────────────────────
        if line == "goBack()":
            if scene_history:
                return scene_history.pop()
            else:
                push_line("[No previous scene]", WARN_COLOR)
            continue

        # ── clear_text() ──────────────────────────────────────
        if line == "clear_text()": line_buf.clear(); continue

        # ── image_data({...}) ─────────────────────────────────
        m = re.match(r'^image_data\((.+)\)$', line, re.DOTALL)
        if m:
            try: set_image(json.loads(m.group(1)))
            except Exception as e: push_line(f"[image_data error: {e}]", WARN_COLOR)
            continue

        # ── image("path") / image("path","caption",secs) ──────
        m = re.match(r'^image\("([^"]+)"(?:,\s*"([^"]*)")?(?:,\s*([\d.]+))?\)$', line)
        if m:
            path    = m.group(1)
            caption = m.group(2) or ""
            wait    = float(m.group(3)) if m.group(3) else 0.0
            if caption or wait:
                await show_image_fullscreen(path, caption, wait)
            else:
                load_image_file(path)
            continue

        # ── clear_image() ─────────────────────────────────────
        if line == "clear_image()": clear_image(); continue

        # ── hud_title("...") ──────────────────────────────────
        m = re.match(r'^hud_title\("(.*)"\)$', line)
        if m:
            global hud_title_text
            hud_title_text = interpolate(m.group(1))
            continue

        # ── hud_desc("...") ───────────────────────────────────
        m = re.match(r'^hud_desc\("(.*)"\)$', line)
        if m:
            global hud_desc_text
            hud_desc_text = interpolate(m.group(1))
            continue

        # ── stats() ───────────────────────────────────────────
        if line == "stats()":
            push_blank(); push_line("── STATS ──────────────────", GOLD_COLOR)
            for k, v in sorted(vars_.items()):
                if k.startswith("player."):
                    push_line(f"  {k[7:].replace('_',' ').title():<18} {v}")
            inv = vars_.get("inventory", [])
            if inv: push_line(f"  {'Items':<18} {', '.join(inv)}")
            push_line("────────────────────────────", GOLD_COLOR); push_blank()
            continue

        # ── var = input("...") ────────────────────────────────
        m = re.match(r'^(\S+)\s*=\s*input\("(.*)"\)$', line)
        if m:
            raw = await get_input(interpolate(m.group(2)))
            try: vars_[m.group(1)] = int(raw)
            except ValueError:
                try: vars_[m.group(1)] = float(raw)
                except ValueError: vars_[m.group(1)] = raw
            continue

        # ── var = random(min, max) ────────────────────────────
        m = re.match(r'^(\S+)\s*=\s*random\((\d+),\s*(\d+)\)$', line)
        if m: vars_[m.group(1)] = random.randint(int(m.group(2)),int(m.group(3))); continue

        # ── var = value ───────────────────────────────────────
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.+)$', line)
        if m and not line.startswith("if ") and not line.startswith("elif "):
            vars_[m.group(1)] = resolve(m.group(2).strip()); continue

        # ── var += / -= / *= ──────────────────────────────────
        m = re.match(r'^(\S+)\s*(\+|-|\*)=\s*(.+)$', line)
        if m:
            var, op, rhs = m.group(1), m.group(2), m.group(3)
            try:
                curr   = float(vars_.get(var, 0)); rv = float(resolve(rhs))
                result = curr+rv if op=="+" else curr-rv if op=="-" else curr*rv
                vars_[var] = int(result) if result == int(result) else result
            except (ValueError, TypeError):
                if op == "+": vars_[var] = str(vars_.get(var,"")) + str(resolve(rhs))
            continue

        # ── give("item") / take("item") ───────────────────────
        m = re.match(r'^give\("?([^")]+)"?\)$', line)
        if m:
            item = m.group(1)
            vars_.setdefault("inventory", [])
            if item not in vars_["inventory"]: vars_["inventory"].append(item)
            continue

        m = re.match(r'^take\("?([^")]+)"?\)$', line)
        if m:
            inv  = vars_.get("inventory", [])
            item = m.group(1)
            if item in inv: inv.remove(item)
            continue

        # ── flag(name) / unflag(name) ─────────────────────────
        m = re.match(r'^flag\(([^)]+)\)$', line)
        if m: flags_[m.group(1).strip()] = True; continue

        m = re.match(r'^unflag\(([^)]+)\)$', line)
        if m: flags_[m.group(1).strip()] = False; continue

        # ── goto(Scene) ───────────────────────────────────────
        m = re.match(r'^goto\((.+)\)$', line)
        if m:
            scene_history.append(current_scene)
            return m.group(1).strip()

        # ── call(Scene) ───────────────────────────────────────
        m = re.match(r'^call\((.+)\)$', line)
        if m:
            result = await run_lines(scenes_.get(m.group(1).strip(), []))
            if result and result != "__return__": return result
            continue

        # ── end() ─────────────────────────────────────────────
        if line == "end()": return "__end__"

        # ── choice("..."): / option("...") -> Scene ───────────
        m = re.match(r'^choice\("(.*)"\):?$', line)
        if m:
            prompt  = m.group(1); options = []
            while i < len(lines):
                ol = lines[i].strip(); i += 1
                if not ol or ol.startswith("//"): continue
                om = re.match(r'^option\("(.+)"\)\s*->\s*(.+)$', ol)
                if om: options.append((om.group(1), om.group(2).strip()))
                else: i -= 1; break
            push_blank(); push_line(interpolate(prompt), GOLD_COLOR)
            for idx, (txt, _) in enumerate(options, 1):
                push_line(f"  [{idx}]  {interpolate(txt)}", (180,200,240))
            push_blank()
            while True:
                raw = await get_input()
                if raw.isdigit() and 1 <= int(raw) <= len(options):
                    scene_history.append(current_scene)
                    return options[int(raw)-1][1]
                push_line("  Enter a number from the list.", WARN_COLOR)
            continue

        # ── if condition: / elif / else: / end_if ─────────────
        m = re.match(r'^if\s+(.+):$', line)
        if m:
            cond     = m.group(1); blocks = []; cur_cond = cond; cur_block = []; depth = 1
            while i < len(lines):
                bl = lines[i].strip(); i += 1
                if not bl or bl.startswith("//"): continue
                if re.match(r'^if\s+.+:$', bl): depth += 1; cur_block.append(bl); continue
                if bl == "end_if":
                    depth -= 1
                    if depth == 0: blocks.append((cur_cond, cur_block)); break
                    cur_block.append(bl); continue
                em = re.match(r'^elif\s+(.+):$', bl)
                if em and depth == 1:
                    blocks.append((cur_cond, cur_block)); cur_cond = em.group(1); cur_block = []; continue
                if bl == "else:" and depth == 1:
                    blocks.append((cur_cond, cur_block)); cur_cond = None; cur_block = []; continue
                cur_block.append(bl)
            done = False
            for bc, bl2 in blocks:
                if not done and (bc is None or evaluate(bc)):
                    result = await run_lines(bl2)
                    if result: return result
                    done = True
            continue

        # ── chance(percent): ... end_chance ───────────────────
        m = re.match(r'^chance\((\d+)\):$', line)
        if m:
            pct = int(m.group(1)); cbody = []
            while i < len(lines):
                cl = lines[i].strip(); i += 1
                if cl == "end_chance": break
                cbody.append(cl)
            if random.randint(1,100) <= pct:
                result = await run_lines(cbody)
                if result: return result
            continue

    return None

# ─────────────────────────────────────────────────────────────
# ASYNC MAIN
# ─────────────────────────────────────────────────────────────
async def run_game(script_path):
    global current_scene
    load_script(script_path)
    current_scene = "__main__"
    next_scene    = "__main__"

    while next_scene and next_scene != "__end__":
        if next_scene not in scenes_:
            push_line(f"[error] Scene not found: '{next_scene}'", WARN_COLOR)
            draw_frame()
            await wait_enter()
            break
        current_scene = next_scene
        result        = await run_lines(scenes_[current_scene])
        next_scene    = result

    push_blank()
    push_line(" THAT'S THE END ", GOLD_COLOR)
    draw_frame()
    while True:
        pump()
        draw_frame()
        clock.tick(FPS)
        await asyncio.sleep(0)

async def main():
    script = "game.txt"          # hardcoded — sys.argv not available in browser
    if not os.path.exists(script):
        push_line(f"Script not found: {script}", WARN_COLOR)
        draw_frame()
        while True:
            pump(); draw_frame(); clock.tick(FPS)
            await asyncio.sleep(0)
        return
    await run_game(script)

asyncio.run(main())