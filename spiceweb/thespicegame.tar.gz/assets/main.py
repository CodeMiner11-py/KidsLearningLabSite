"""
main.py  -  Pygame Text Adventure Script Engine (PygBag / WebAssembly build)
Reads a .txt game script and renders it in a Pygame terminal window.

Local dev:   python main.py
Web build:   pygbag .   (run from the folder containing main.py)

Script usage:
  travel(7, "Trebizond")              -- travel for 7 days toward Trebizond
                                         drains food/water each day, press I for inventory
  travel(7, "Trebizond", RoadEvents)  -- same, but rolls one event from RoadEvents
                                         at the START of each day; travel pauses,
                                         event runs (full script commands), player
                                         presses Enter, then travel resumes

  event_table(MyEvents):           -- define a named event table
    event(30, "Dust storm"):       -- 30% weight, label shown to player
      warn("A dust storm hits!")
      player.water -= 1
    end_event
    event(10, "Oasis"):
      print("You find an oasis!")
      player.water += 2
    end_event
  end_event_table

  roll_event(MyEvents)             -- roll one event from MyEvents (weighted)
  roll_events(MyEvents, 2)         -- roll exactly 2 events (no repeats)
"""

import pygame, sys, os, time, random, textwrap, re, json, asyncio, math

# ─────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────
WIDTH          = 800
HEIGHT         = 600
FPS            = 60
scene_history  = []
BG_COLOR       = (0, 0, 0)
TEXT_COLOR     = (210, 200, 170)
INPUT_COLOR    = (255, 240, 180)
GOLD_COLOR     = (212, 175,  55)
ASIDE_COLOR    = (120, 140, 180)
WARN_COLOR     = (220, 100,  60)
BORDER_COLOR   = (60,  120, 220)
BORDER_WIDTH   = 2
FONT_FILE      = "HomeVideo.ttf"
FONT_SIZE      = 17
LINE_SPACING   = 6
MARGIN_X       = 32

IMAGE_AREA_H   = 180
BORDER_Y_TOP   = IMAGE_AREA_H + 8
BORDER_Y_BOT   = HEIGHT - 56
TEXT_AREA_TOP  = BORDER_Y_TOP + BORDER_WIDTH + 8
TEXT_AREA_BOT  = BORDER_Y_BOT - 8
MAX_LINES      = 80

TITLE_FONT_SIZE   = 28
CAPTION_FONT_SIZE = 18
HUD_TITLE_Y       = 8
HUD_CAPTION_Y     = IMAGE_AREA_H - 28

SCROLL_SPEED   = 3
CURSOR_BLINK   = 500

# ─────────────────────────────────────────────────────────────
# STATE
# ─────────────────────────────────────────────────────────────
vars_         = {}
scenes_       = {}
event_tables_ = {}   # name -> [(weight, label, [lines])]
current_scene = "__main__"
flags_        = {}
line_buf      = []
scroll_offset = 0

hud_title_text = "the silk road"
hud_desc_text  = "Travel from Constantinople to Calicut and trade spices."

# ─────────────────────────────────────────────────────────────
# PYGAME INIT
# ─────────────────────────────────────────────────────────────
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Road to Calicut")
clock  = pygame.time.Clock()

def load_font(size):
    try:
        return pygame.font.Font(FONT_FILE, size)
    except Exception:
        return pygame.font.SysFont("monospace", size)

font         = load_font(FONT_SIZE)
LINE_H       = font.get_height() + LINE_SPACING
title_font   = load_font(TITLE_FONT_SIZE)
caption_font = load_font(CAPTION_FONT_SIZE)
small_font   = load_font(13)

# ─────────────────────────────────────────────────────────────
# PIXEL IMAGE
# ─────────────────────────────────────────────────────────────
current_image = None

async def die():
    # Pixel skull (11x11, ps=12)
    K = (220, 220, 220)
    _ = None

    skull_rows = [
        [_, K, K, K, K, K, K, K, K, K, _],
        [K, K, K, K, K, K, K, K, K, K, K],
        [K, K, K, K, K, K, K, K, K, K, K],
        [K, K, _, _, K, K, K, _, _, K, K],
        [K, K, _, _, K, K, K, _, _, K, K],
        [K, K, K, K, K, K, K, K, K, K, K],
        [K, K, K, K, K, K, K, K, K, K, K],
        [K, K, K, K, K, K, K, K, K, K, K],
        [K, K, K, K, K, K, K, K, K, K, K],
        [_, K, K, K, K, K, K, K, K, K, _],
        [_, _, K, _, K, _, K, _, K, _, _],
    ]

    ps = 12
    skull_surf = pygame.Surface((11 * ps, 11 * ps), pygame.SRCALPHA)
    skull_surf.fill((0, 0, 0, 0))
    for ri, row in enumerate(skull_rows):
        for ci, cell in enumerate(row):
            if cell:
                pygame.draw.rect(skull_surf, cell, (ci * ps, ri * ps, ps, ps))

    sw, sh = skull_surf.get_size()

    BTN_W, BTN_H = 500, 44
    btn_x = WIDTH  // 2 - BTN_W // 2
    btn_y = HEIGHT // 2 + sh // 2 + 40
    title_surf = title_font.render("YOU DIED", True, (220, 40, 40))

    hovered = False

    while True:
        pump()
        mx, my = pygame.mouse.get_pos()
        hovered = btn_x <= mx <= btn_x + BTN_W and btn_y <= my <= btn_y + BTN_H

        # Check for click or Enter
        try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit(); sys.exit()
                    if event.key == pygame.K_RETURN:
                        await _restart()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if hovered:
                        quit()
                        exit()
        except Exception:
            pass

        screen.fill((0, 0, 0))

        # Skull
        screen.blit(skull_surf, (WIDTH // 2 - sw // 2, HEIGHT // 2 - sh // 2 - 60))

        # Title
        screen.blit(title_surf, (WIDTH // 2 - title_surf.get_width() // 2,
                                  HEIGHT // 2 - sh // 2 - 60 + sh + 16))

        # Button
        btn_color = (160, 30, 30) if hovered else (80, 15, 15)
        pygame.draw.rect(screen, btn_color,   (btn_x, btn_y, BTN_W, BTN_H), border_radius=4)
        pygame.draw.rect(screen, (220, 40, 40), (btn_x, btn_y, BTN_W, BTN_H), 2, border_radius=4)
        btn_text = caption_font.render("QUIT GAME (reload to play again)", True, (220, 220, 220))
        screen.blit(btn_text, (btn_x + BTN_W // 2 - btn_text.get_width() // 2,
                                btn_y + BTN_H // 2 - btn_text.get_height() // 2))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


async def _restart():
    global vars_, flags_, line_buf, scroll_offset, scene_history, current_scene
    global hud_title_text, hud_desc_text, current_image, _camel_surf
    vars_          = {}
    flags_         = {}
    line_buf       = []
    scroll_offset  = 0
    scene_history  = []
    current_scene  = "__main__"
    current_image  = None
    _camel_surf    = None
    hud_title_text = "the silk road"
    hud_desc_text  = "Travel from Constantinople to Calicut and trade spices."
    await run_game("game.txt")

def _parse_col(v):
    if v is None: return None
    if isinstance(v, (list, tuple)): return tuple(v)
    named = {"black":(0,0,0),"white":(255,255,255),"red":(200,0,0),
             "green":(0,180,0),"blue":(0,0,200),"gold":(212,175,55),
             "yellow":(255,220,0),"brown":(139,90,43),"grey":(160,160,160)}
    return named.get(str(v).lower(), (255,255,255))

def build_pixel_surface(data):
    ps      = data.get("pixel_size", 6)
    palette = {k: _parse_col(v) for k, v in data.get("palette", {}).items()}
    rows    = data.get("data", [])
    if not rows: return None
    cols = max(len(r) for r in rows)
    surf = pygame.Surface((cols * ps, len(rows) * ps), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    for ri, row in enumerate(rows):
        for ci, cell in enumerate(row):
            color = palette.get(cell) if isinstance(cell, str) else _parse_col(cell)
            if color: pygame.draw.rect(surf, color, (ci*ps, ri*ps, ps, ps))
    return surf

def set_image(data):
    global current_image
    current_image = build_pixel_surface(data)

def load_image_file(path):
    global current_image
    try:
        if path.lower().endswith(".png"):
            current_image = pygame.image.load(path).convert_alpha()
        else:
            with open(path) as f:
                set_image(json.load(f))
    except Exception as e:
        push_line(f"[image error: {e}]", WARN_COLOR)

def clear_image():
    global current_image
    current_image = None

# ─────────────────────────────────────────────────────────────
# TEXT BUFFER
# ─────────────────────────────────────────────────────────────
def push_line(text, color=None):
    if color is None: color = TEXT_COLOR
    text = interpolate(str(text))
    max_chars = max(1, (WIDTH - MARGIN_X * 2) // max(1, font.size("A")[0]))
    for seg in text.splitlines():
        if seg.strip() == "":
            line_buf.append(("", color))
        else:
            for w in textwrap.wrap(seg, max_chars) or [""]:
                line_buf.append((w, color))
    while len(line_buf) > MAX_LINES:
        line_buf.pop(0)

def push_blank():
    line_buf.append(("", TEXT_COLOR))

# ─────────────────────────────────────────────────────────────
# DRAW (normal mode)
# ─────────────────────────────────────────────────────────────
def draw_frame(input_text="", cursor_vis=True, prompt_active=False):
    screen.fill(BG_COLOR)

    if current_image:
        iw, ih = current_image.get_size()
        screen.blit(current_image, ((WIDTH - iw) // 2, max(0, (IMAGE_AREA_H - ih) // 2)))

    if hud_title_text:
        t = title_font.render(hud_title_text, True, GOLD_COLOR)
        screen.blit(t, ((WIDTH - t.get_width()) // 2, HUD_TITLE_Y))

    if hud_desc_text:
        c = caption_font.render(hud_desc_text, True, TEXT_COLOR)
        screen.blit(c, ((WIDTH - c.get_width()) // 2, HUD_CAPTION_Y))

    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_TOP, WIDTH, BORDER_WIDTH))
    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_BOT, WIDTH, BORDER_WIDTH))

    text_h  = TEXT_AREA_BOT - TEXT_AREA_TOP
    max_vis = text_h // LINE_H
    display = list(line_buf)
    if prompt_active:
        cur = "_" if cursor_vis else " "
        display.append((">  " + input_text + cur, INPUT_COLOR))

    total   = len(display)
    bot_idx = total - scroll_offset
    top_idx = max(0, bot_idx - max_vis)
    bot_idx = min(bot_idx, total)

    for idx, (text, color) in enumerate(display[top_idx:bot_idx]):
        if text:
            screen.blit(font.render(text, True, color), (MARGIN_X, TEXT_AREA_TOP + idx * LINE_H))

    pygame.display.flip()

# ─────────────────────────────────────────────────────────────
# TRAVEL ANIMATION
# ─────────────────────────────────────────────────────────────

SKY_TOP    = (20,  18,  40)
SKY_BOT    = (180, 120,  50)
SAND_LIGHT = (210, 170,  90)
SAND_MID   = (190, 145,  65)
SAND_DARK  = (160, 115,  40)
DUNE_COLOR = (200, 155,  70)
SUN_COLOR  = (255, 220, 100)

def _draw_desert_bg(scroll_x, area_h):
    area = pygame.Surface((WIDTH, area_h))

    # Sky - flat light blue
    pygame.draw.rect(area, (135, 185, 220), (0, 0, WIDTH, area_h // 2))

    # Sun
    pygame.draw.circle(area, SUN_COLOR,          (WIDTH - 80, 28), 20)
    pygame.draw.circle(area, (255, 240, 150),    (WIDTH - 80, 28), 14)

    horizon = area_h // 2

    # Far dunes (slow parallax)
    far_scroll = int(scroll_x * 0.3) % (WIDTH + 120)
    for dx in range(-120, WIDTH + 240, 120):
        cx = (dx - far_scroll) % (WIDTH + 120) - 60
        pygame.draw.ellipse(area, SAND_DARK, (cx - 80, horizon - 10, 160, 36))

    # Near dunes (fast parallax)
    near_scroll = int(scroll_x * 0.9) % (WIDTH + 160)
    for dx in range(-160, WIDTH + 320, 160):
        cx = (dx - near_scroll) % (WIDTH + 160) - 80
        pygame.draw.ellipse(area, DUNE_COLOR, (cx - 100, horizon + 4, 200, 56))

    # Sand floor
    pygame.draw.rect(area, SAND_MID,   (0, horizon + 8,  WIDTH, area_h - horizon - 8))
    pygame.draw.rect(area, SAND_LIGHT, (0, area_h - 28,  WIDTH, 28))

    return area


def _build_camel():

    H = (192, 128, 64)
    B = (128, 128, 64)
    C = (64, 64, 64)
    D = (128, 64, 64)
    E = (64, 64, 0)
    F = (64, 0, 0)
    G = (128, 64, 0)
    H = (192, 128, 64)
    I = (128, 128, 0)
    J = (192, 128, 0)
    K = (0, 0, 0)
    L = (192, 192, 128)
    M = (255, 192, 128)
    _ = None

    # Bundle colors
    BN = (180, 100, 40)   # bundle body — rust brown
    ST = (90,  60, 20)    # strap — dark brown

    ps = 9
    rows = [
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, H, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, B, C, D, D, E, E, E, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, D, D, D, E, F, G, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, E, G, E, G, D, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, H, D, E, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, F, E, E, E, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, H, H, H, D, D, F, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, D, E, E, G, E, _, _, _, _, _, _, _, _, _, _, H, H, H, D, H, H, H, H, H, B, C, E, C, _, _, _, _, _, _, _, _, _, _, _, _, _, _],
        # Row 10 — bundle sits on hump (cols 21-28)
        [_, _, _, _, _, _, _, F, G, G, G, _, _, _, _, _, _, _, _, H, H,BN,BN,BN,BN,BN,BN,BN, H, B, D, D, E, F, _, _, _, _, _, _, _, _, _, _, _, _, _],
        # Row 11 — bundle body + strap across middle
        [_, _, _, _, _, _, _, E, G, G, G, E, _, _, _, _, _, _, H, H, H,BN,ST,ST,ST,ST,ST,BN, H, H, B, D, D, D, D, D, H, H, _, _, _, _, _, _, _, _, _, _],
        # Row 12 — bundle bottom
        [_, _, _, _, _, _, _, _, E, G, G, G, _, _, _, _, _, H, H, H, H,BN,BN,BN,BN,BN,BN,BN, H, D, G, G, E, E, G, D, B, G, E, D, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, E, G, G, G, E, _, _, B, G, B, H, D, D, H, H, H, H, H, G, G, B, G, D, G, E, F, F, E, E, G, D, E, E, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, G, G, E, E, G, E, E, G, G, H, H, G, B, H, H, H, H, B, H, G, D, D, G, D, G, G, D, H, E, E, D, D, D, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, G, E, E, E, E, G, E, G, B, G, G, G, G, I, H, H, D, G, G, G, G, G, E, G, G, G, E, E, E, D, E, C, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, G, G, E, E, E, G, G, G, G, G, G, G, G, G, J, J, G, G, G, G, G, E, E, E, E, E, E, E, E, E, E, D, K, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, G, E, G, G, G, G, G, G, G, E, G, G, G, G, G, G, G, G, E, E, E, E, E, E, F, E, E, E, E, F, F, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, G, G, G, G, G, G, G, G, G, E, E, E, E, E, E, F, E, E, E, E, K, K, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, G, G, G, G, G, G, G, G, G, E, E, E, E, E, E, F, G, G, G, E, K, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, G, G, J, J, G, G, G, G, G, G, G, G, _, E, K, G, G, G, G, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, E, _, _, J, G, G, G, G, G, G, _, _, _, _, E, G, G, G, G, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, E, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, G, G, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, G, G, _, _, _, _, _, _, _, _, _, _, _, _, _, G, E, E, G, G, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, I, _, G, _, _, _, _, _, _, _, _, _, _, _, _, _, _, E, E, G, G, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, B, _, B, _, _, _, _, _, _, _, _, _, _, _, _, _, _, E, F, _, I, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, B, I, L, E, _, _, _, _, _, _, _, _, _, _, _, _, _, F, F, _, I, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, H, B, _, G, _, _, _, _, _, _, _, _, _, _, _, _, _, F, F, _, G, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, H, _, _, I, _, _, _, _, _, _, _, _, _, _, _, _, _, F, E, _, _, G, E, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, _, _, _, _, _, _, _, _, _, _, _, _, _, E, E, _, _, G, G, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, I, _, _, H, _, _, _, _, _, _, _, _, _, _, _, _, _, E, _, _, _, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, H, _, _, H, _, _, _, _, _, _, _, _, _, _, _, _, _, E, _, _, _, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, B, _, _, L, _, _, _, _, _, _, _, _, _, _, _, _, E, _, _, _, _, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, _, _, L, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, L, _, _, _, M, D, _, _, _, _, _, _, _, _, _, _, E, _, _, _, _, _, _, _, _, _, _, _],
        [_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, G, _, _, _, _, _, _, _, _, _, _, _, _],
    ]

    cols = len(rows[0])
    surf = pygame.Surface((cols * ps, len(rows) * ps), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    for ri, row in enumerate(rows):
        for ci, cell in enumerate(row):
            if cell:
                pygame.draw.rect(surf, cell, (ci * ps, ri * ps, ps, ps))
    return surf


_camel_surf      = None
_travel_show_inv = False

def _draw_travel_frame_nodisplay(scroll_x, camel_bob, day, total_days, destination, show_inv):
    global _camel_surf
    if _camel_surf is None:
        _camel_surf = _build_camel()

    screen.fill(BG_COLOR)
    desert = _draw_desert_bg(scroll_x, IMAGE_AREA_H)
    screen.blit(desert, (0, 0))

    flipped = pygame.transform.flip(_camel_surf, True, False)
    cw, ch  = flipped.get_size()
    max_h   = IMAGE_AREA_H - 36
    if ch > max_h:
        scale   = max_h / ch
        flipped = pygame.transform.scale(flipped, (int(cw * scale), int(ch * scale)))
        cw, ch  = flipped.get_size()
    cx = WIDTH // 2 - cw // 2
    cy = IMAGE_AREA_H - 28 - ch
    screen.blit(flipped, (cx, cy))

    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_TOP, WIDTH, BORDER_WIDTH))
    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_BOT, WIDTH, BORDER_WIDTH))

    pad   = 10
    bar_y = TEXT_AREA_TOP + pad
    progress = day / max(total_days, 1)
    bar_w    = WIDTH - MARGIN_X * 2
    pygame.draw.rect(screen, (20, 20, 20),  (MARGIN_X, bar_y, bar_w, 8), border_radius=4)
    pygame.draw.rect(screen, GOLD_COLOR,    (MARGIN_X, bar_y, int(bar_w * progress), 8), border_radius=4)

    dest_t = caption_font.render(f"Day {day} of {total_days}  ->  {destination}", True, GOLD_COLOR)
    screen.blit(dest_t, (MARGIN_X, bar_y + 12))

    row1_y = bar_y + 12 + dest_t.get_height() + 10
    col_w  = (WIDTH - MARGIN_X * 2) // 5

    def stat(label, val, color, x, y):
        ls = small_font.render(label, True, (100, 100, 100))
        vs = caption_font.render(str(val), True, color)
        screen.blit(ls, (x, y))
        screen.blit(vs, (x, y + ls.get_height() + 2))

    stats = [
        ("GOLD",   vars_.get("player.gold",   0), GOLD_COLOR),
        ("HEALTH", vars_.get("player.health", 0), (100, 220, 100)),
        ("FOOD",   vars_.get("player.food",   0), (220, 160,  80)),
        ("WATER",  vars_.get("player.water",  0), ( 80, 180, 255)),
        ("GUARDS", vars_.get("player.guards", 0), (180, 180, 200)),
    ]
    for idx, (lbl, val, col) in enumerate(stats):
        stat(lbl, val, col, MARGIN_X + idx * col_w, row1_y)

    hint_y = row1_y + 54
    if show_inv:
        items = [
            f"Mastic:{vars_.get('player.mastic',0)}",
            f"Saffron:{vars_.get('player.saffron',0)}",
            f"Rosewater:{vars_.get('player.rosewater',0)}",
            f"Theriac:{vars_.get('player.theriac',0)}",
            f"Letters:{vars_.get('player.letters',0)}",
        ]
        inv_t = small_font.render("  ".join(items), True, ASIDE_COLOR)
        screen.blit(inv_t, (MARGIN_X, hint_y))
        hint_y += small_font.get_height() + 4

    hint = small_font.render("[ I ] show inventory" if not show_inv else "[ I ] hide inventory",
                             True, (60, 60, 60))
    screen.blit(hint, (MARGIN_X, hint_y))
    # NOTE: no display.flip() here

def _draw_travel_frame(scroll_x, camel_bob, day, total_days, destination, show_inv):
    global _camel_surf
    if _camel_surf is None:
        _camel_surf = _build_camel()

    screen.fill(BG_COLOR)

    # ── Desert in image area ───────────────────────────────────
    desert = _draw_desert_bg(scroll_x, IMAGE_AREA_H)
    screen.blit(desert, (0, 0))

    # Camel centred, sitting on sand floor
    # Camel centred, sitting on sand floor — flipped & scaled to fit
    flipped = pygame.transform.flip(_camel_surf, True, False)
    cw, ch  = flipped.get_size()
    max_h   = IMAGE_AREA_H - 36
    if ch > max_h:
        scale   = max_h / ch
        flipped = pygame.transform.scale(flipped, (int(cw * scale), int(ch * scale)))
        cw, ch  = flipped.get_size()
    cx = WIDTH // 2 - cw // 2
    cy = IMAGE_AREA_H - 28 - ch
    screen.blit(flipped, (cx, cy))

    # ── Borders ────────────────────────────────────────────────
    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_TOP, WIDTH, BORDER_WIDTH))
    pygame.draw.rect(screen, BORDER_COLOR, (0, BORDER_Y_BOT, WIDTH, BORDER_WIDTH))

    # ── Stats HUD in text area ─────────────────────────────────
    pad   = 10
    bar_y = TEXT_AREA_TOP + pad

    # Progress bar
    progress = day / max(total_days, 1)
    bar_w    = WIDTH - MARGIN_X * 2
    pygame.draw.rect(screen, (40, 40, 60),  (MARGIN_X, bar_y, bar_w, 8), border_radius=4)
    pygame.draw.rect(screen, GOLD_COLOR,    (MARGIN_X, bar_y, int(bar_w * progress), 8), border_radius=4)

    # Destination label
    dest_t = caption_font.render(f"Day {day} of {total_days}  →  {destination}", True, GOLD_COLOR)
    screen.blit(dest_t, (MARGIN_X, bar_y + 12))

    # Stat columns
    row1_y = bar_y + 12 + dest_t.get_height() + 10
    col_w  = (WIDTH - MARGIN_X * 2) // 5

    def stat(label, val, color, x, y):
        ls = small_font.render(label, True, (130, 130, 160))
        vs = caption_font.render(str(val), True, color)
        screen.blit(ls, (x, y))
        screen.blit(vs, (x, y + ls.get_height() + 2))

    stats = [
        ("GOLD",   vars_.get("player.gold",   0), GOLD_COLOR),
        ("HEALTH", vars_.get("player.health", 0), (100, 220, 100)),
        ("FOOD",   vars_.get("player.food",   0), (220, 160,  80)),
        ("WATER",  vars_.get("player.water",  0), ( 80, 180, 255)),
        ("GUARDS", vars_.get("player.guards", 0), (180, 180, 200)),
    ]
    for idx, (lbl, val, col) in enumerate(stats):
        stat(lbl, val, col, MARGIN_X + idx * col_w, row1_y)

    # Inventory toggle
    hint_y = row1_y + 54
    if show_inv:
        items = [
            f"Mastic:{vars_.get('player.mastic',0)}",
            f"Saffron:{vars_.get('player.saffron',0)}",
            f"Rosewater:{vars_.get('player.rosewater',0)}",
            f"Theriac:{vars_.get('player.theriac',0)}",
            f"Letters:{vars_.get('player.letters',0)}",
        ]
        inv_t = small_font.render("  ".join(items), True, ASIDE_COLOR)
        screen.blit(inv_t, (MARGIN_X, hint_y))
        hint_y += small_font.get_height() + 4

    hint = small_font.render("[ I ] show inventory" if not show_inv else "[ I ] hide inventory",
                             True, (80, 80, 110))
    screen.blit(hint, (MARGIN_X, hint_y))

    pygame.display.flip()


async def do_travel(total_days, destination, event_table_name=None):
    global _travel_show_inv
    _travel_show_inv = False

    scroll_x     = 0.0
    camel_bob    = 0.0
    day          = 0
    DAY_DURATION = 4.0

    def _draw_event_popup(popup_lines, label):
        # Draw travel frame WITHOUT calling display.flip
        _draw_travel_frame_nodisplay(scroll_x, camel_bob, day, total_days, destination, _travel_show_inv)
        # Dim
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 180))
        screen.blit(dim, (0, 0))
        # Box
        PAD   = 20
        BOX_W = WIDTH - 120
        BOX_H = 200
        BOX_X = (WIDTH - BOX_W) // 2
        BOX_Y = (HEIGHT - BOX_H) // 2
        pygame.draw.rect(screen, (12, 12, 12),  (BOX_X, BOX_Y, BOX_W, BOX_H), border_radius=4)
        pygame.draw.rect(screen, GOLD_COLOR,    (BOX_X, BOX_Y, BOX_W, BOX_H), 2, border_radius=4)
        lbl_surf = caption_font.render(label, True, GOLD_COLOR)
        screen.blit(lbl_surf, (BOX_X + PAD, BOX_Y + PAD))
        ty = BOX_Y + PAD + lbl_surf.get_height() + 8
        for text, color in popup_lines:
            if text:
                screen.blit(font.render(text, True, color), (BOX_X + PAD, ty))
                ty += LINE_H
        pygame.display.flip()

    async def _fire_day_event(day_num):
        table = event_tables_.get(event_table_name) if event_table_name else None
        if not table:
            return
        # Run guaranteed events first
        for w, lbl_a, body_a in event_tables_.get(event_table_name + "__always__", []):
            await run_lines(body_a)

        # Then roll one normal event as usual
        entry = _pick_weighted(table)
        if entry is None:
            return
        _, lbl, body = entry

        has_wait = any(re.match(r'^wait\([\d.]+\)$', l.strip()) for l in body)
        popup_lines = []

        # Redirect push_line into popup_lines instead of line_buf
        original_push_line = globals()['push_line']
        def popup_push_line(text, color=None):
            if color is None: color = TEXT_COLOR
            text = interpolate(str(text))
            max_chars = max(1, (WIDTH - MARGIN_X * 2) // max(1, font.size("A")[0]))
            for seg in text.splitlines():
                if seg.strip() == "":
                    pass
                else:
                    for w in textwrap.wrap(seg, max_chars) or [""]:
                        popup_lines.append((w, color))
            _draw_event_popup(popup_lines, lbl)

        import builtins
        globals()['push_line'] = popup_push_line

        # Override wait() behavior to render popup during wait
        original_draw_frame = globals()['draw_frame']
        def popup_draw_frame(*args, **kwargs):
            _draw_event_popup(popup_lines, lbl)
        globals()['draw_frame'] = popup_draw_frame

        try:
            await run_lines(body)
        finally:
            globals()['push_line']    = original_push_line
            globals()['draw_frame']   = original_draw_frame

        if not popup_lines and not has_wait:
            return

        if not has_wait:
            popup_lines.append(("[ Press Enter to continue ]", ASIDE_COLOR))
            _draw_event_popup(popup_lines, lbl)
            global _input_ready, _input_text
            _input_ready = False
            _input_text  = ""
            while not _input_ready:
                pump()
                _draw_event_popup(popup_lines, lbl)
                clock.tick(FPS)
                await asyncio.sleep(0)
            _input_ready = False
        else:
            _draw_event_popup(popup_lines, lbl)

    while day < total_days:
        day += 1

        food  = round(max(0, float(vars_.get("player.food",  0)) - 0.2), 1)
        water = round(max(0, float(vars_.get("player.water", 0)) - 0.3), 1)
        vars_["player.food"]  = food
        vars_["player.water"] = water
        if food <= 0 or water <= 0:
            hp = int(vars_.get("player.health", 100))
            if food <= 0:
                vars_["player.health"] = max(0, hp - 10)
            if water <= 0:
                vars_["player.health"] = max(0, hp - 20)

        await _fire_day_event(day)

        if int(vars_.get("player.health", 100)) <= 0:
            await die()
            return

        day_timer = 0.0
        while day_timer < DAY_DURATION:
            dt = clock.tick(FPS) / 1000.0
            try:
                pg_events = pygame.event.get()
            except Exception:
                pg_events = []
            for event in pg_events:
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit(); sys.exit()
                    elif event.key == pygame.K_i:
                        _travel_show_inv = not _travel_show_inv
            scroll_x  += dt * 80
            camel_bob += dt * 4.0
            day_timer += dt
            _draw_travel_frame(scroll_x, camel_bob, day, total_days, destination, _travel_show_inv)
            await asyncio.sleep(0)

    push_blank()
    push_line(f"You arrive at {destination} after {total_days} days.", GOLD_COLOR)
    push_line(f"  Food remaining:  {vars_.get('player.food',  0)}", (220, 160, 80))
    push_line(f"  Water remaining: {vars_.get('player.water', 0)}", ( 80, 180, 255))
    push_line(f"  Health:          {vars_.get('player.health',100)}", (100, 220, 100))
    push_blank()

# ─────────────────────────────────────────────────────────────
# EVENT PUMP
# ─────────────────────────────────────────────────────────────
_input_text   = ""
_input_ready  = False
_input_result = ""

def pump():
    global scroll_offset, _input_text, _input_ready, _input_result
    try:
        events = pygame.event.get()
    except Exception:
        return
    for event in events:
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()
            elif event.key == pygame.K_RETURN:
                _input_result = _input_text.strip()
                _input_text   = ""
                _input_ready  = True
            elif event.key == pygame.K_BACKSPACE:
                _input_text = _input_text[:-1]
            elif event.unicode and event.unicode.isprintable():
                _input_text += event.unicode
        if event.type == pygame.MOUSEWHEEL:
            scroll_offset = max(0, min(scroll_offset - event.y * SCROLL_SPEED,
                                       len(line_buf) - 1))

# ─────────────────────────────────────────────────────────────
# ASYNC INPUT
# ─────────────────────────────────────────────────────────────
async def get_input(prompt=""):
    global scroll_offset, _input_ready, _input_result, _input_text
    if prompt:
        push_line(prompt, INPUT_COLOR)
    scroll_offset = 0
    _input_ready  = False
    _input_text   = ""
    cur_vis       = True
    last_blink    = pygame.time.get_ticks()

    while not _input_ready:
        now = pygame.time.get_ticks()
        if now - last_blink > CURSOR_BLINK:
            cur_vis    = not cur_vis
            last_blink = now
        pump()
        draw_frame(input_text=_input_text, cursor_vis=cur_vis, prompt_active=True)
        clock.tick(FPS)
        await asyncio.sleep(0)

    result       = _input_result
    _input_ready = False
    push_line(">  " + result, INPUT_COLOR)
    return result

async def wait_enter(msg="[ Press Enter to continue ]"):
    push_blank()
    push_line(msg, ASIDE_COLOR)
    await get_input()
    push_blank()

# ─────────────────────────────────────────────────────────────
# ASYNC FULLSCREEN IMAGE
# ─────────────────────────────────────────────────────────────
async def show_image_fullscreen(path, caption="", wait_secs=0.0):
    try:
        if path.lower().endswith(".png"):
            surf = pygame.image.load(path).convert_alpha()
        else:
            with open(path) as f:
                surf = build_pixel_surface(json.load(f))
    except Exception as e:
        push_line(f"[image error: {e}]", WARN_COLOR)
        return

    if surf is None:
        return

    font_cap = load_font(30)
    iw, ih   = surf.get_size()
    scale    = min(WIDTH / iw, HEIGHT / ih)
    if scale > 1:
        scale = max(1, int(scale))
    scaled   = pygame.transform.scale(surf, (int(iw * scale), int(ih * scale)))
    sw, sh   = scaled.get_size()
    ix       = (WIDTH  - sw) // 2
    iy       = (HEIGHT - sh) // 2
    cap_h    = 100 if caption else 0
    end_time = (asyncio.get_event_loop().time() + wait_secs) if wait_secs > 0 else None

    while True:
        pump()
        screen.fill((0, 0, 0))
        screen.blit(scaled, (ix, iy))
        if caption:
            cap_surf = pygame.Surface((WIDTH, cap_h))
            cap_surf.fill((0, 0, 0))
            cap_surf.set_alpha(210)
            screen.blit(cap_surf, (0, HEIGHT - cap_h))
            txt = font_cap.render(caption, True, (200, 190, 150))
            screen.blit(txt, (MARGIN_X, HEIGHT - cap_h + (cap_h - txt.get_height()) // 2))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
        if end_time and asyncio.get_event_loop().time() >= end_time:
            break

# ─────────────────────────────────────────────────────────────
# VARIABLE HELPERS
# ─────────────────────────────────────────────────────────────
def resolve(val):
    val = str(val).strip()
    if (val.startswith('"') and val.endswith('"')) or \
       (val.startswith("'") and val.endswith("'")):
        return val[1:-1]
    try: return int(val)
    except ValueError: pass
    try: return float(val)
    except ValueError: pass
    return vars_.get(val, val)

def interpolate(text):
    return re.sub(r'\{([^}]+)\}',
                  lambda m: str(vars_.get(m.group(1).strip(), "{"+m.group(1)+"}")), text)

def evaluate(cond):
    cond = cond.strip()
    m = re.match(r'^has\((.+)\)$', cond)
    if m: return m.group(1).strip().strip('"\'') in vars_.get("inventory", [])
    m = re.match(r'^flag\((.+)\)$', cond)
    if m: return bool(flags_.get(m.group(1).strip()))
    m = re.match(r'^not\s+flag\((.+)\)$', cond)
    if m: return not bool(flags_.get(m.group(1).strip()))
    for op in (">=","<=","!=","==",">","<"):
        if op in cond:
            l, r = cond.split(op, 1)
            lv, rv = resolve(l.strip()), resolve(r.strip())
            try: lv, rv = float(lv), float(rv)
            except (ValueError, TypeError): lv, rv = str(lv), str(rv)
            return {"==":lv==rv,"!=":lv!=rv,">=":lv>=rv,"<=":lv<=rv,">":lv>rv,"<":lv<rv}[op]
    v = vars_.get(cond)
    return bool(v) and str(v) not in ("false","False","0","")

# ─────────────────────────────────────────────────────────────
# PARSER  (now also collects event_table blocks)
# ─────────────────────────────────────────────────────────────
def load_script(path):
    global scenes_, event_tables_
    scenes_, event_tables_ = {}, {}
    cur_name, cur_lines    = "__main__", []

    # We do a single-pass parse; event_table blocks are lifted out.
    raw_lines = open(path, encoding="utf-8").readlines()
    cleaned   = [l.rstrip("\n") for l in raw_lines]

    i = 0
    while i < len(cleaned):
        line = cleaned[i]
        s    = line.strip()
        i   += 1

        if s.startswith("//"): continue

        # New scene header
        if s.startswith("##"):
            scenes_[cur_name] = cur_lines
            cur_name, cur_lines = s[2:].strip(), []
            continue

        # event_table block: lifted out, not inserted into scene lines
        m = re.match(r'^event_table\((\w+)\):?$', s)
        if m:
            table_name   = m.group(1)
            table_events = []   # list of (weight, label, [body_lines])
            while i < len(cleaned):
                el = cleaned[i].strip(); i += 1
                if el == "end_event_table": break
                if el.startswith("//"): continue
                em = re.match(r'^event\((\d+),\s*"([^"]*)"\):?$', el)
                if em:
                    w, lbl = int(em.group(1)), em.group(2)
                    body   = []
                    while i < len(cleaned):
                        bl = cleaned[i].strip(); i += 1
                        if bl == "end_event": break
                        body.append(bl)
                    table_events.append((w, lbl, body))
            event_tables_[table_name] = table_events
            # Split guaranteed events out into a parallel key
            event_tables_[table_name + "__always__"] = [(w, l, b) for w, l, b in table_events if w == -1]
            event_tables_[table_name] = [(w, l, b) for w, l, b in table_events if w != -1]
            continue

        cur_lines.append(line)

    scenes_[cur_name] = cur_lines


# ─────────────────────────────────────────────────────────────
# RANDOM EVENT HELPERS
# ─────────────────────────────────────────────────────────────
def _pick_weighted(table):
    """Pick one (weight, label, body) entry from table using weights."""
    total = sum(w for w, _, _ in table)
    if total <= 0:
        return None
    roll  = random.randint(1, total)
    acc   = 0
    for entry in table:
        acc += entry[0]
        if roll <= acc:
            return entry
    return table[-1]


async def run_roll_event(table_name, count=1):
    """
    Roll `count` distinct events from the named table.
    Shows the event label in GOLD, then runs its body lines.
    """
    table = event_tables_.get(table_name)
    if not table:
        push_line(f"[roll_event: unknown table '{table_name}']", WARN_COLOR)
        return

    pool  = list(table)
    fired = 0
    while fired < count and pool:
        entry = _pick_weighted(pool)
        if entry is None:
            break
        w, lbl, body = entry
        pool.remove(entry)
        fired += 1

        push_blank()
        push_line(f"── Event: {lbl} ──", GOLD_COLOR)
        result = await run_lines(body)
        if result:
            return result   # propagate gotos/ends out of event body

# ─────────────────────────────────────────────────────────────
# ASYNC EXECUTOR
# ─────────────────────────────────────────────────────────────
async def run_lines(lines, start=0):
    global current_scene
    i = start
    while i < len(lines):
        line = lines[i].strip(); i += 1
        if not line or line.startswith("//"): continue

        pump()
        draw_frame()
        await asyncio.sleep(0)

        # ── print("...") ──────────────────────────────────────
        m = re.match(r'^print\("(.*)"\)$', line, re.DOTALL)
        if m: push_line(m.group(1)); continue

        # ── print_color("...", R, G, B) ───────────────────────
        m = re.match(r'^print_color\("(.*)",\s*(\d+),\s*(\d+),\s*(\d+)\)$', line)
        if m:
            push_line(m.group(1), (int(m.group(2)),int(m.group(3)),int(m.group(4))))
            continue

        if line == "die()": await die(); continue

        # ── header("...") ─────────────────────────────────────
        m = re.match(r'^header\("(.*)"\)$', line)
        if m:
            push_blank(); push_line("==  "+m.group(1).upper()+"  ==", GOLD_COLOR); push_blank()
            continue

        # ── aside("...") ──────────────────────────────────────
        m = re.match(r'^aside\("(.*)"\)$', line)
        if m: push_line("  [ "+m.group(1)+" ]", ASIDE_COLOR); continue

        # ── warn("...") ───────────────────────────────────────
        m = re.match(r'^warn\("(.*)"\)$', line)
        if m: push_line("  !  "+m.group(1), WARN_COLOR); continue

        # ── typewrite("...") ──────────────────────────────────
        m = re.match(r'^typewrite\("(.*)"\)$', line)
        if m:
            text = interpolate(m.group(1))
            push_line("")
            idx = len(line_buf) - 1
            displayed = ""
            for ch in text:
                displayed += ch
                line_buf[idx] = (displayed, TEXT_COLOR)
                pump(); draw_frame()
                await asyncio.sleep(0.03)
            continue

        # ── blank() ───────────────────────────────────────────
        if line == "blank()": push_blank(); continue

        # ── divider() ─────────────────────────────────────────
        if line == "divider()":
            push_line("  .  .  .  .  .  .  .  .  .  .  .  .  .", (60,80,120))
            continue

        # ── wait(n) ───────────────────────────────────────────
        m = re.match(r'^wait\(([\d.]+)\)$', line)
        if m:
            end = asyncio.get_event_loop().time() + float(m.group(1))
            while asyncio.get_event_loop().time() < end:
                pump(); draw_frame()
                await asyncio.sleep(0)
            continue

        # ── pause() ───────────────────────────────────────────
        if line == "pause()": await wait_enter(); continue

        # ── goBack() ──────────────────────────────────────────
        if line == "goBack()":
            if scene_history:
                return scene_history.pop()
            else:
                push_line("[No previous scene]", WARN_COLOR)
            continue

        # ── clear_text() ──────────────────────────────────────
        if line == "clear_text()": line_buf.clear(); continue

        # ── image_data({...}) ─────────────────────────────────
        m = re.match(r'^image_data\((.+)\)$', line, re.DOTALL)
        if m:
            try: set_image(json.loads(m.group(1)))
            except Exception as e: push_line(f"[image_data error: {e}]", WARN_COLOR)
            continue

        # ── image("path") / image("path","caption",secs) ──────
        m = re.match(r'^image\("([^"]+)"(?:,\s*"([^"]*)")?(?:,\s*([\d.]+))?\)$', line)
        if m:
            path    = m.group(1)
            caption = m.group(2) or ""
            wait    = float(m.group(3)) if m.group(3) else 0.0
            if caption or wait:
                await show_image_fullscreen(path, caption, wait)
            else:
                load_image_file(path)
            continue

        # ── clear_image() ─────────────────────────────────────
        if line == "clear_image()": clear_image(); continue

        # ── hud_title("...") ──────────────────────────────────
        m = re.match(r'^hud_title\("(.*)"\)$', line)
        if m:
            global hud_title_text
            hud_title_text = interpolate(m.group(1))
            continue

        # ── hud_desc("...") ───────────────────────────────────
        m = re.match(r'^hud_desc\("(.*)"\)$', line)
        if m:
            global hud_desc_text
            hud_desc_text = interpolate(m.group(1))
            continue

        # ── stats() ───────────────────────────────────────────
        if line == "stats()":
            push_blank(); push_line("── STATS ──────────────────", GOLD_COLOR)
            for k, v in sorted(vars_.items()):
                if k.startswith("player."):
                    push_line(f"  {k[7:].replace('_',' ').title():<18} {v}")
            inv = vars_.get("inventory", [])
            if inv: push_line(f"  {'Items':<18} {', '.join(inv)}")
            push_line("────────────────────────────", GOLD_COLOR); push_blank()
            continue

        # ── travel(days, "Destination") / travel(days, "Destination", TableName) ──
        m = re.match(r'^travel\((\d+),\s*"([^"]+)"(?:,\s*(\w+))?\)$', line)
        if m:
            await do_travel(int(m.group(1)), m.group(2), m.group(3))
            continue

        # ── roll_event(TableName) ─────────────────────────────
        m = re.match(r'^roll_event\((\w+)\)$', line)
        if m:
            result = await run_roll_event(m.group(1), count=1)
            if result: return result
            continue

        # ── roll_events(TableName, N) ─────────────────────────
        m = re.match(r'^roll_events\((\w+),\s*(\d+)\)$', line)
        if m:
            result = await run_roll_event(m.group(1), count=int(m.group(2)))
            if result: return result
            continue

        # ── var = input("...") ────────────────────────────────
        m = re.match(r'^(\S+)\s*=\s*input\("(.*)"\)$', line)
        if m:
            raw = await get_input(interpolate(m.group(2)))
            try: vars_[m.group(1)] = int(raw)
            except ValueError:
                try: vars_[m.group(1)] = float(raw)
                except ValueError: vars_[m.group(1)] = raw
            continue

        # ── var = random(min, max) ────────────────────────────
        m = re.match(r'^(\S+)\s*=\s*random\((\d+),\s*(\d+)\)$', line)
        if m: vars_[m.group(1)] = random.randint(int(m.group(2)),int(m.group(3))); continue

        # ── var = value ───────────────────────────────────────
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.+)$', line)
        if m and not line.startswith("if ") and not line.startswith("elif "):
            vars_[m.group(1)] = resolve(m.group(2).strip()); continue

        # ── var += / -= / *= ──────────────────────────────────
        m = re.match(r'^(\S+)\s*(\+|-|\*)=\s*(.+)$', line)
        if m:
            var, op, rhs = m.group(1), m.group(2), m.group(3)
            try:
                curr   = float(vars_.get(var, 0)); rv = float(resolve(rhs))
                result = curr+rv if op=="+" else curr-rv if op=="-" else curr*rv
                vars_[var] = int(result) if result == int(result) else result
            except (ValueError, TypeError):
                if op == "+": vars_[var] = str(vars_.get(var,"")) + str(resolve(rhs))
            continue

        # ── give("item") / take("item") ───────────────────────
        m = re.match(r'^give\("?([^")]+)"?\)$', line)
        if m:
            item = m.group(1)
            vars_.setdefault("inventory", [])
            if item not in vars_["inventory"]: vars_["inventory"].append(item)
            continue

        m = re.match(r'^take\("?([^")]+)"?\)$', line)
        if m:
            inv  = vars_.get("inventory", [])
            item = m.group(1)
            if item in inv: inv.remove(item)
            continue

        # ── flag(name) / unflag(name) ─────────────────────────
        m = re.match(r'^flag\(([^)]+)\)$', line)
        if m: flags_[m.group(1).strip()] = True; continue

        m = re.match(r'^unflag\(([^)]+)\)$', line)
        if m: flags_[m.group(1).strip()] = False; continue

        # ── goto(Scene) ───────────────────────────────────────
        m = re.match(r'^goto\((.+)\)$', line)
        if m:
            scene_history.append(current_scene)
            return m.group(1).strip()

        # ── call(Scene) ───────────────────────────────────────
        m = re.match(r'^call\((.+)\)$', line)
        if m:
            result = await run_lines(scenes_.get(m.group(1).strip(), []))
            if result and result != "__return__": return result
            continue

        # ── end() ─────────────────────────────────────────────
        if line == "end()": return "__end__"

        # ── choice("..."): / option("...") -> Scene ───────────
        m = re.match(r'^choice\("(.*)"\):?$', line)
        if m:
            prompt  = m.group(1); options = []
            while i < len(lines):
                ol = lines[i].strip(); i += 1
                if not ol or ol.startswith("//"): continue
                om = re.match(r'^option\("(.+)"\)\s*->\s*(.+)$', ol)
                if om: options.append((om.group(1), om.group(2).strip()))
                else: i -= 1; break
            push_blank(); push_line(interpolate(prompt), GOLD_COLOR)
            for idx, (txt, _) in enumerate(options, 1):
                push_line(f"  [{idx}]  {interpolate(txt)}", (180,200,240))
            push_blank()
            while True:
                raw = await get_input()
                if raw.isdigit() and 1 <= int(raw) <= len(options):
                    scene_history.append(current_scene)
                    return options[int(raw)-1][1]
                push_line("  Enter a number from the list.", WARN_COLOR)
            continue

        # ── if condition: / elif / else: / end_if ─────────────
        m = re.match(r'^if\s+(.+):$', line)
        if m:
            cond     = m.group(1); blocks = []; cur_cond = cond; cur_block = []; depth = 1
            while i < len(lines):
                bl = lines[i].strip(); i += 1
                if not bl or bl.startswith("//"): continue
                if re.match(r'^if\s+.+:$', bl): depth += 1; cur_block.append(bl); continue
                if bl == "end_if":
                    depth -= 1
                    if depth == 0: blocks.append((cur_cond, cur_block)); break
                    cur_block.append(bl); continue
                em = re.match(r'^elif\s+(.+):$', bl)
                if em and depth == 1:
                    blocks.append((cur_cond, cur_block)); cur_cond = em.group(1); cur_block = []; continue
                if bl == "else:" and depth == 1:
                    blocks.append((cur_cond, cur_block)); cur_cond = None; cur_block = []; continue
                cur_block.append(bl)
            done = False
            for bc, bl2 in blocks:
                if not done and (bc is None or evaluate(bc)):
                    result = await run_lines(bl2)
                    if result: return result
                    done = True
            continue

        # ── chance(percent): ... end_chance ───────────────────
        m = re.match(r'^chance\((\d+)\):$', line)
        if m:
            pct = int(m.group(1)); cbody = []
            while i < len(lines):
                cl = lines[i].strip(); i += 1
                if cl == "end_chance": break
                cbody.append(cl)
            if random.randint(1,100) <= pct:
                result = await run_lines(cbody)
                if result: return result
            continue

    return None

# ─────────────────────────────────────────────────────────────
# ASYNC MAIN
# ─────────────────────────────────────────────────────────────
async def run_game(script_path):
    global current_scene
    load_script(script_path)
    current_scene = "__main__"
    next_scene    = "__main__"

    while next_scene and next_scene != "__end__":
        if next_scene not in scenes_:
            push_line(f"[error] Scene not found: '{next_scene}'", WARN_COLOR)
            draw_frame()
            await wait_enter()
            break
        current_scene = next_scene
        result        = await run_lines(scenes_[current_scene])
        next_scene    = result

    push_blank()
    push_line(" THAT'S THE END ", GOLD_COLOR)
    draw_frame()
    while True:
        pump()
        draw_frame()
        clock.tick(FPS)
        await asyncio.sleep(0)

async def main():
    script = "game.txt"
    if not os.path.exists(script):
        push_line(f"Script not found: {script}", WARN_COLOR)
        draw_frame()
        while True:
            pump(); draw_frame(); clock.tick(FPS)
            await asyncio.sleep(0)
        return
    await run_game(script)

asyncio.run(main())