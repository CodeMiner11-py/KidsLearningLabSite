// GBing v3 – content.js
// Runs at document_start; DOM work deferred to DOMContentLoaded.

const GOOGLE_LOGO =
  'https://www.gstatic.com/marketing-cms/assets/images/c5/3a/200414104c669203c62270f7884f/google-wordmarks-2x.webp=n-w200-h64-fcrop64=1,00000000ffffffff-rw';

const GEMINI_LOGO =
  'https://raw.githubusercontent.com/lobehub/lobe-icons/refs/heads/master/packages/static-png/light/gemini-color.png';

const REDIRECT_BASE = 'https://kidslearninglab.com/redirect?url=';

// ── Scopes that map to real Google URLs ──────────────────────────────────────
const SCOPE_MAP = {
  'b-scopeListItem-images':    'https://images.google.com/search?q=',
  'b-scopeListItem-video':     'https://www.google.com/search?tbm=vid&q=',
  'b-scopeListItem-news':      'https://news.google.com/search?q=',
  'b-scopeListItem-shop':      'https://www.google.com/search?tbm=shop&q=',
  'b-scopeListItem-flights':   'https://www.google.com/flights',
  'b-scopeListItem-travelhub': 'https://www.google.com/travel',
  'b-scopeListItem-local':     'https://maps.google.com/maps?q=',
};

// ── Helpers ──────────────────────────────────────────────────────────────────

function getQuery() {
  return new URLSearchParams(location.search).get('q') || '';
}

function makeRedirect(url) {
  return REDIRECT_BASE + encodeURIComponent(url);
}

// ── Text replacement ─────────────────────────────────────────────────────────

const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'HEAD']);

function replaceTextInNode(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    const orig = node.nodeValue;
    let next = orig
      .replace(/\bBing\b/g, 'Google')
      .replace(/\bbing\b/g, 'google')
      // Copilot → Gemini
      .replace(/\bCopilot\b/g, 'Gemini')
      .replace(/\bcopilot\b/g, 'gemini')
      .replace(/\bCoPilot\b/g, 'Gemini');
    if (next !== orig) node.nodeValue = next;
  } else if (node.nodeType === Node.ELEMENT_NODE && !SKIP_TAGS.has(node.tagName)) {
    for (const child of node.childNodes) replaceTextInNode(child);
  }
}

function patchTitle() {
  document.title = document.title
    .replace(/\bBing\b/g, 'Google')
    .replace(/\bCopilot\b/g, 'Gemini');
}

// ── Logo ─────────────────────────────────────────────────────────────────────

function injectLogo() {
  const area = document.querySelector('.b_logoArea');
  if (!area) return;

  // Remove existing logo link / h1
  area.querySelectorAll('*').forEach(el => el.style.display = 'none');

  const a = document.createElement('a');
  a.href = makeRedirect('https://www.google.com');
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.id = 'gbing-logo-link';
  a.style.cssText = 'display:flex;align-items:center;text-decoration:none;';

  const img = document.createElement('img');
  img.src = GOOGLE_LOGO;
  img.id = 'gbing-logo';
  img.alt = 'Google';
  img.style.cssText = 'display:block;width:92px;height:30px;object-fit:contain;object-position:left center;';

  a.appendChild(img);
  area.appendChild(a);
}

// ── Favicon ──────────────────────────────────────────────────────────────────

function setFavicon() {
  let link = document.querySelector("link[rel~='icon']");
  if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
  }
  link.href = 'https://www.google.com/favicon.ico';
}

// ── Copilot / AI / Bing-specific UI removal ──────────────────────────────────

function removeCopilot() {
  const selectors = [
    '#b_copilot_search_container', '#b_copilot_search', '#b_bop_cs_sb',
    '#b_sydConvOuter', '#b_sydConvCont', '#b_sydWelcomeTemplate',
    '#b_chat_external_content', '#b_TriviaOverlay',
    '[id*="copilot"]', '[class*="copilot"]',
    '[id*="syd"]', '[class*="syd"]',
    '#b-scopeListItem-copilotsearch',
    '#mic_0D9F035', '#mic_0C7691D', '.mic_cont',
    '#sbiarea', '#sb_sbip',
  ];
  selectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => el.remove());
  });
}

// ── Replace Copilot scope tab with Gemini ───────────────────────────────────

function injectGeminiScope() {
  // Look for any scope list item labelled "Copilot" or "copilotsearch"
  const convItem = document.getElementById('b-scopeListItem-conv');
  const csItem   = document.getElementById('b-scopeListItem-copilotsearch');
  const target   = convItem || csItem;
  if (!target) return;

  const q = getQuery();
  const geminiUrl = 'https://gemini.google.com/app?q=' + encodeURIComponent(q);

  target.id = 'gbing-gemini-scope';
  target.className = (target.className || '') + ' gbing-gemini-scope';

  const a = target.querySelector('a') || document.createElement('a');
  a.href = makeRedirect(geminiUrl);
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.removeAttribute('h');
  a.removeAttribute('data-h');

  // Build inner content
  const icon = document.createElement('img');
  icon.src = GEMINI_LOGO;
  icon.alt = 'Gemini';
  icon.className = 'gbing-gemini-icon';
  icon.style.cssText = 'width:14px;height:14px;vertical-align:middle;object-fit:contain;';

  const span = document.createElement('span');
  span.textContent = 'Gemini';

  a.innerHTML = '';
  a.appendChild(icon);
  a.appendChild(span);

  if (!target.contains(a)) target.appendChild(a);

  // Also remove the old copilot SVG inside if it exists
  target.querySelectorAll('svg').forEach(s => s.remove());
}

// ── Scope-bar: remap to Google ───────────────────────────────────────────────

function remapScopeBar() {
  const q = getQuery();
  Object.entries(SCOPE_MAP).forEach(([id, base]) => {
    const li = document.getElementById(id);
    if (!li) return;
    const a = li.querySelector('a');
    if (!a) return;
    const dest = base + (base.endsWith('=') ? encodeURIComponent(q) : '');
    a.href = makeRedirect(dest);
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.removeAttribute('h');
    a.removeAttribute('data-h');
  });
}

// ── Remove mic and camera buttons from search bar ────────────────────────────

function removeMicCamera() {
  const selectors = [
    '.mic_cont', '#sbiarea', '#sb_sbip', '#sb_sbi', '#sbi_b',
    '[id^="mic_"]', '.mic_icon', '#vs_mic_icon', '.vs_mic_icon_mai',
    '#sb_clt', '.sb_clrhov',
  ];
  selectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => el.remove());
  });
}

// ── Redirect ALL links through kidslearninglab ────────────────────────────────

const ALREADY   = /kidslearninglab\.com\/redirect/;
const SKIP_HREF = /^(javascript:|#|mailto:|tel:)/;

function isLocalLink(href) {
  if (!href || SKIP_HREF.test(href)) return true;
  try {
    const url = new URL(href, location.href);
    return url.hostname === location.hostname || url.hostname === '';
  } catch (e) {
    return true;
  }
}

function redirectLink(a) {
  const href = a.getAttribute('href');
  if (!href || ALREADY.test(href)) return;
  if (a.id === 'gbing-logo-link') return;
  if (isLocalLink(href)) return;
  a.setAttribute('href', makeRedirect(href));
  a.setAttribute('target', '_blank');
  a.setAttribute('rel', 'noopener noreferrer');
  a.removeAttribute('h');
  a.removeAttribute('data-h');
}

function redirectAllLinks(root = document) {
  root.querySelectorAll('a[href]').forEach(redirectLink);
}

// ── Attribute patches (aria-labels etc.) ────────────────────────────────────

function patchAttributes(root = document) {
  const attrs = ['aria-label', 'placeholder', 'title', 'alt'];
  root.querySelectorAll('*').forEach(el => {
    attrs.forEach(attr => {
      const v = el.getAttribute(attr);
      if (v && /\bBing\b/.test(v))
        el.setAttribute(attr, v.replace(/\bBing\b/g, 'Google'));
      if (v && /\bCopilot\b/i.test(v))
        el.setAttribute(attr, (el.getAttribute(attr) || '').replace(/\bCopilot\b/ig, 'Gemini'));
    });
  });
  const go = document.getElementById('sb_go_par');
  if (go) go.setAttribute('data-sbtip', 'Search Google');
}

// ── MutationObserver for dynamic content ─────────────────────────────────────

function watchDOM() {
  const obs = new MutationObserver(mutations => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        replaceTextInNode(node);
        redirectAllLinks(node);

        // Re-remove copilot / mic if re-injected
        const id  = node.id || '';
        const cls = typeof node.className === 'string' ? node.className : '';
        if (/copilot|syd/i.test(id) || /copilot|syd/i.test(cls)) {
          node.remove();
          continue;
        }
        if (/mic_cont|sbiarea|sb_sbip/i.test(id) || /mic_cont/i.test(cls)) {
          node.remove();
        }
      }
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });

  // Title watcher
  const titleEl = document.querySelector('title');
  if (titleEl) {
    new MutationObserver(patchTitle).observe(titleEl, { childList: true, characterData: true, subtree: true });
  }
}

// ── Rewards: inject points counter into scopebar ─────────────────────────────

function injectRewardsScope() {
  // Bing stores the points in #id_rbh — try several known child selectors
  const rbh = document.getElementById('id_rbh');
  if (!rbh) return;

  // Extract the numeric points value from any text node / span inside
  const raw = rbh.innerText || rbh.textContent || '';
  const match = raw.match(/[\d,]+/);
  if (!match) return;
  const points = match[0];

  // Find the rewards link href so clicking goes to the real rewards page
  const rewardLink = rbh.closest('a') || document.querySelector('#id_rh a') || null;
  const href = rewardLink ? rewardLink.href : 'https://rewards.bing.com/';

  // Don't double-inject
  if (document.getElementById('gbing-rewards-scope')) return;

  const scopebar = document.querySelector('.b_scopebar ul, .b_scopebar');
  if (!scopebar) return;

  const li = document.createElement('li');
  li.id = 'gbing-rewards-scope';

  const a = document.createElement('a');
  a.href = href;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.title = 'Microsoft Rewards';

  // Star icon + points number
  a.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span id="gbing-rewards-pts">${points}</span>`;

  li.appendChild(a);

  const ul = scopebar.tagName === 'UL' ? scopebar : scopebar.querySelector('ul');
  if (ul) ul.appendChild(li);
}

// ── Inject Google Fonts via <link> (CSS @import blocked in extensions) ────────

function injectFonts() {
  const preconnect1 = document.createElement('link');
  preconnect1.rel = 'preconnect';
  preconnect1.href = 'https://fonts.googleapis.com';
  document.head.appendChild(preconnect1);

  const preconnect2 = document.createElement('link');
  preconnect2.rel = 'preconnect';
  preconnect2.href = 'https://fonts.gstatic.com';
  preconnect2.crossOrigin = 'anonymous';
  document.head.appendChild(preconnect2);

  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Google+Sans:ital,opsz,wght@0,17..18,400..700;1,17..18,400..700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap';
  document.head.appendChild(link);
}

// ── Main ──────────────────────────────────────────────────────────────────────

function main() {
  injectFonts();
  setFavicon();
  patchTitle();
  injectLogo();
  removeCopilot();
  removeMicCamera();
  injectGeminiScope();
  remapScopeBar();
  replaceTextInNode(document.body);
  patchAttributes();
  redirectAllLinks();
  // Rewards points may load async — try now and retry after a delay
  injectRewardsScope();
  setTimeout(injectRewardsScope, 2000);
  watchDOM();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', main);
} else {
  main();
}
