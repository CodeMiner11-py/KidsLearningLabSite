document.body.innerHTML = `
  <h1 style="color:blue; font-size:36px; text-align:center; margin-top:0; margin-bottom:10px;">
    You're using Jupiter Ed Plus
  </h1>


<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Albert+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<style>

* {font-family: "Albert Sans";}

</style>


` + document.body.innerHTML; // prepend without removing existing content



const css = `
#touchnavbtn {
  background-color: hsl(180,50%,44%) !important;
  color: white !important;
}
`;

const style = document.createElement('style');
style.textContent = css;
document.head.appendChild(style);
