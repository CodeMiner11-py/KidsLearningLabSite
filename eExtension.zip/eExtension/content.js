// =============================
// Inject header at top of page
// =============================
const header = document.createElement("h1");
header.textContent = "You're using Jupiter Ed Plus";
header.style.color = "blue";
header.style.fontSize = "36px";
header.style.textAlign = "center";
header.style.margin = "0 0 10px 0";
document.body.prepend(header);

// =============================
// Inject Google Font <link> tags
// =============================
const fontLinks = [
  "https://fonts.googleapis.com/css2?family=Albert+Sans:wght@400;700&display=swap",
  "https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap",
  "https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap",
  "https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&display=swap"
];

fontLinks.forEach(url => {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = url;
  document.head.appendChild(link);
});

// =============================
// Font switching (press F)
// =============================
const fontFamilies = [
  "'Albert Sans', sans-serif",
  "'Inter', sans-serif",
  "'Nunito', sans-serif",
  "'DM Sans', sans-serif",
"'Space Grotesk', sans-serif",
"'Stack Sans Notch', sans-serif",
"'Poppins', sans-serif",
"'Impact', sans-serif",
"'Lora', sans-serif",
"'Great Vibes', sans-serif"
];

let fontIndex = parseInt(localStorage.getItem("font_index")) || 0;
const fontStyle = document.createElement("style");
fontStyle.id = "dynamicFontStyle";
document.head.appendChild(fontStyle);

function applyFont() {
  fontStyle.textContent = `* { font-family: ${fontFamilies[fontIndex]} !important; }`;
}

applyFont();

let lastKey = '';
document.addEventListener("keydown", e => {
  if (lastKey === '/' && e.key.toUpperCase() === 'F') {
    fontIndex = (fontIndex + 1) % fontFamilies.length;
    localStorage.setItem("font_index", fontIndex);
    applyFont();
  }
  lastKey = e.key;
});


// =============================
// Aqua Theme – Only CSS-defined elements
// =============================
let hue = parseInt(localStorage.getItem("aqua_h")) || 180;
const overrideStyle = document.createElement("style");
document.head.appendChild(overrideStyle);

function applyAquaCSS() {
  overrideStyle.textContent = `
    /* Backgrounds */
    body, .bgcolor, #pagebuttons, .progspace { background-color: hsl(${hue},50%,93%) !important; }
    #submast, #minisubmast { background: linear-gradient(to top, hsl(${hue},50%,93%) 0px, hsl(${hue},50%,93%) 10px) !important; }
    #tipbox { border:2px solid hsl(${hue},50%,86%) !important; }
    .bgborder, .graybord { border-color: hsl(${hue},50%,86%) !important; }
    .planmask { background: linear-gradient(to right, hsl(${hue},50%,93%) 40px, transparent 40px) !important; }

    /* Buttons / main color */
    .btn, .dimbtn, .btncolor, .menuabtndark, #logobg1, #logobg2, #loginlogobg,
    .tab:hover, .toptab1:hover, .toptab1hi, .navrow:hover, .classtab:hover,
    .classsemi:hover, .darkhi:hover, .btntran:hover, .btntranlit, .darker,
    .jupbtnlit, .jupbtn:hover, #podprogspace, .caldate:hover, .caldim:hover,
    .caltoday, .btnllit, .findbg .rowhi:hover, .xhover,
    .poduidark { background-color: hsl(${hue},50%,44%) !important; }
    .logotext { color: hsl(${hue},50%,44%) !important; }

    /* Bars / darker shades */
    #bar1, #sidebar, .darkbox, .dark, .darkhi, .navlist, .topnav1list, .navtab,
    .navtabdim, #tipbox, .topnav2list .navlit, #loginbar1, .minibar, .podbar1,
    .podbar2, .podbtnrim, .jupbtns, .calbox, #busybar, .findbg, .touchnavbtn {
      background-color: hsl(${hue},50%,32%) !important;
    }
    a, .hyperlink, .clink:hover, color, .colortext, .btnl { color: hsl(${hue},50%,32%) !important; }
    .borderlit { border-color: hsl(${hue},50%,32%) !important; }

    /* Secondary bars / lighter shades */
    #bar2, #leftnav, .tabcurve, .navlit, .classlit, .rowlit, .rowlit td, .menulit,
    .lit, .lit td, .topnav2list, .darkbox .btn, .darkbox .dimbtn, .dark .btn,
    .dark .dimbtn, #podbar1 .btn, .podbtn, .podbtnbig, .podopt0, .podopt1, .callit,
    .sellit, #busydot, .findbg .rowlit { background-color: hsl(${hue},50%,62%) !important; }
    #findbox { border-color: hsl(${hue},50%,62%) !important; }
    .iconstroke, .iconstrokeh { stroke: hsl(${hue},50%,62%) !important; }
    .iconfill, .iconfillh, .menudot { fill: hsl(${hue},50%,62%) !important; }

    /* Hover / highlights */
    .toptab2:hover, .toptab2hi, .topnav2list .navrow:hover, #podbar1 .btn:hover,
    .podbtn:hover, .podbtnbig:hover, .podoptlit, .podopthi:hover, .selhi, .touchnavlit {
      background-color: hsl(${hue},50%,70%) !important;
    }
    .textbox, .textboxp1, .menuclosed, .menuopenbox, .menuabtn, .menulist,
    .menualist, .border, textarea, .darkbox .calbox, box, .pod td,
    .explanation, .annotation { border-color: hsl(${hue},50%,70%) !important; }

    /* Widgets background */
    .shaded, box, .pod td { background-color: hsl(${hue},50%,93%) !important; }

    /* Text colors */
    .darkbox, .dark, .darkhi, .navlist, .topnav1list, .topnav2list, .navtab, .btn,
    .btncolor, .tab, .minitab, #sidebar, .rowlit, .lit, .menulit, .toptab1,
    .toptab1hi, .toptab2, .toptab2hi, .toptabnull, #text_find, #tipbox,
    .btnl:hover, .dark .btnl, .btnllit, #podbar1, #podbar2, .jupbtns, .callabel,
    .calhead, .caldate, .caltoday, .callit, .seat, .seatrollchanged, .findbg,
    .findbg .rowhi:hover, .lit .colortext, .blockhi, .blockun, .colorbg {
      color: white !important;
    }

    /* FORCE touchnavbtn dark */
    .touchnavbtn { background-color: hsl(${hue},50%,32%) !important; }
  `;
}

// Initial application
applyAquaCSS();

// Reinforce after 0.5s
setTimeout(() => {
  const forceBtnStyle = document.createElement("style");
  forceBtnStyle.textContent = `.touchnavbtn { background-color: hsl(${hue},50%,32%) !important; }`;
  document.head.appendChild(forceBtnStyle);
}, 500);

// Q key listener – shift hue for aqua CSS
document.addEventListener("keydown", e => {
  if (e.key.toLowerCase() === "q") {
    hue = (hue + 10) % 360;
    localStorage.setItem("aqua_h", hue);
    applyAquaCSS();
  }
});

setTimeout(() => {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = chrome.runtime.getURL("orange.css");
  document.head.appendChild(link);
}, 500);
